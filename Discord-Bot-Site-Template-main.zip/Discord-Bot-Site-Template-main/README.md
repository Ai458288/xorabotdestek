daha bir çok ücretsiz altyapı ve scriptler için github hesabıma var kod paylaşım sunucuma bakabilirsiniz : 
https://discord.gg/bdfd

Siteyi demo izlemek için: 
https://discord-bot-site-template.vercel.app/

İyi Kullanımlar :>
